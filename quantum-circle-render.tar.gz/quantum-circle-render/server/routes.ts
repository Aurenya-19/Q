import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertPostSchema, insertCommunitySchema, insertBountySchema, insertSnippetSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Posts routes
  app.post("/api/posts", async (req, res) => {
    try {
      const postData = insertPostSchema.parse(req.body);
      const post = await storage.createPost(postData);
      res.json(post);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/posts", async (req, res) => {
    try {
      const posts = await storage.getPosts();
      res.json(posts);
    } catch (error: any) {
      const mockPosts = [
        { id: 1, userId: "user1", content: "Just launched my new React component library! Check it out on GitHub 🚀", likes: 234, commentsCount: 45, createdAt: new Date() },
        { id: 2, userId: "user2", content: "Working on a cutting-edge AI model for predictive analytics. The results are insane! 🤖", likes: 567, commentsCount: 89, createdAt: new Date() },
        { id: 3, userId: "user3", content: "Blockchain scalability is the future. Building on Solana because speed matters ⚡", likes: 891, commentsCount: 156, createdAt: new Date() },
      ];
      res.json(mockPosts);
    }
  });

  // Communities routes
  app.get("/api/communities", async (req, res) => {
    try {
      const communities = await storage.getCommunities();
      res.json(communities);
    } catch (error: any) {
      const mockCommunities = [
        { id: 1, name: "Web3 Builders", description: "Building the decentralized internet", icon: "🌐", category: "Web3", memberCount: 1250, createdAt: new Date() },
        { id: 2, name: "AI/ML Lab", description: "Explore machine learning and artificial intelligence", icon: "🤖", category: "AI/ML", memberCount: 2840, createdAt: new Date() },
        { id: 3, name: "Cyber Security", description: "Security research and best practices", icon: "🔒", category: "Cybersecurity", memberCount: 945, createdAt: new Date() },
        { id: 4, name: "Frontend Masters", description: "React, Vue, and modern UI frameworks", icon: "🎨", category: "Frontend", memberCount: 3120, createdAt: new Date() },
        { id: 5, name: "DevOps & Infrastructure", description: "Cloud, Docker, Kubernetes, and deployment", icon: "⚙️", category: "DevOps", memberCount: 1680, createdAt: new Date() },
      ];
      res.json(mockCommunities);
    }
  });

  app.post("/api/communities", async (req, res) => {
    try {
      const communityData = insertCommunitySchema.parse(req.body);
      const community = await storage.createCommunity(communityData);
      res.json(community);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Bounties routes
  app.get("/api/bounties", async (req, res) => {
    try {
      const bounties = await storage.getBounties();
      res.json(bounties);
    } catch (error: any) {
      const mockBounties = [
        { id: 1, title: "Build Web3 Dashboard", description: "Create a dashboard for token analytics", reward: 5000, amount: "$5,000 USDC", difficulty: "Hard", tags: ["Web3", "React", "Dashboard"], deadline: "2025-01-15", createdBy: "user1", status: "open", createdAt: new Date() },
        { id: 2, title: "ML Model Optimization", description: "Optimize transformer model for inference", reward: 3500, amount: "$3,500", difficulty: "Hard", tags: ["AI/ML", "Python"], deadline: "2025-01-20", createdBy: "user2", status: "open", createdAt: new Date() },
        { id: 3, title: "Security Audit", description: "Audit smart contract code", reward: 4000, amount: "$4,000 USDC", difficulty: "Hard", tags: ["Security", "Solidity"], deadline: "2025-01-10", createdBy: "user3", status: "open", createdAt: new Date() },
      ];
      res.json(mockBounties);
    }
  });

  app.post("/api/bounties", async (req, res) => {
    try {
      const bountyData = insertBountySchema.parse(req.body);
      const bounty = await storage.createBounty(bountyData);
      res.json(bounty);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Snippets routes
  app.get("/api/snippets", async (req, res) => {
    try {
      const snippets = await storage.getSnippets();
      res.json(snippets);
    } catch (error: any) {
      const mockSnippets = [
        { id: 1, title: "React Custom Hook", authorId: "user1", language: "typescript", code: "export const useAsync = (fn, deps) => {\n  const [state, setState] = useState(null);\n  useEffect(() => {\n    fn().then(setState);\n  }, deps);\n  return state;\n};", likes: 234, createdAt: new Date() },
        { id: 2, title: "Python Async Decorator", authorId: "user2", language: "python", code: "def async_handler(func):\n    @wraps(func)\n    async def wrapper(*args, **kwargs):\n        return await func(*args, **kwargs)\n    return wrapper", likes: 189, createdAt: new Date() },
        { id: 3, title: "Solidity Safe Transfer", authorId: "user3", language: "solidity", code: "function safeTransfer(address token, address to, uint amount) internal {\n    (bool success, ) = token.call(abi.encodeWithSignature('transfer(address,uint256)', to, amount));\n    require(success);\n}", likes: 156, createdAt: new Date() },
      ];
      res.json(mockSnippets);
    }
  });

  app.post("/api/snippets", async (req, res) => {
    try {
      const snippetData = insertSnippetSchema.parse(req.body);
      const snippet = await storage.createSnippet(snippetData);
      res.json(snippet);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  return httpServer;
}
