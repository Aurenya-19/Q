import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Chat from "@/pages/Chat";
import Leaderboard from "@/pages/Leaderboard";
import Communities from "@/pages/Communities";
import Profile from "@/pages/Profile";
import Bounties from "@/pages/Bounties";
import Snippets from "@/pages/Snippets";
import Events from "@/pages/Events";
import Assistant from "@/pages/Assistant";
import Workspace from "@/pages/Workspace";
import Focus from "@/pages/Focus";
import Security from "@/pages/Security";
import Nexus from "@/pages/Nexus";
import Intel from "@/pages/Intel";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/nexus" component={Nexus} />
      <Route path="/intel" component={Intel} />
      <Route path="/chat" component={Chat} />
      <Route path="/leaderboard" component={Leaderboard} />
      <Route path="/communities" component={Communities} />
      <Route path="/bounties" component={Bounties} />
      <Route path="/snippets" component={Snippets} />
      <Route path="/events" component={Events} />
      <Route path="/assistant" component={Assistant} />
      <Route path="/workspace" component={Workspace} />
      <Route path="/focus" component={Focus} />
      <Route path="/security" component={Security} />
      <Route path="/profile" component={Profile} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
    </QueryClientProvider>
  );
}

export default App;
