import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, DollarSign, Clock, Code, Shield, Zap } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function Bounties() {
  const { data: bounties = [] } = useQuery({
    queryKey: ["bounties"],
    queryFn: async () => {
      const res = await fetch("/api/bounties");
      return res.json();
    },
  });

  const getDifficultyColor = (difficulty: string) => {
    switch(difficulty.toLowerCase()) {
      case 'easy': return 'border-green-500 text-green-500';
      case 'medium': return 'border-yellow-500 text-yellow-500';
      case 'hard': return 'border-orange-500 text-orange-500';
      case 'expert': return 'border-red-500 text-red-500';
      default: return 'border-primary/50 text-primary';
    }
  };

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex justify-between items-end">
          <div>
            <h1 className="text-4xl font-display font-bold mb-2 text-glow">Bounty Board</h1>
            <p className="text-muted-foreground">Solve problems, earn rewards, and build your reputation.</p>
          </div>
          <Button className="bg-accent text-accent-foreground hover:bg-accent/90 font-bold">
            <Zap className="w-4 h-4 mr-2" /> Post a Bounty
          </Button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search bounties by tag, language, or difficulty..." className="pl-10 bg-card/30 border-border/50 focus-visible:ring-accent" />
        </div>

        <div className="grid gap-4">
          {Array.isArray(bounties) && bounties.length > 0 ? bounties.map((bounty: any) => (
            <Card key={bounty.id} className="p-6 border-border/50 bg-card/30 backdrop-blur-sm hover:border-primary/50 transition-all group">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-xl font-display font-bold group-hover:text-primary transition-colors">{bounty.title}</h3>
                    <Badge variant="outline" className={getDifficultyColor(bounty.difficulty)}>
                      {bounty.difficulty}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" /> <span>{bounty.deadline}</span>
                    </div>
                    <div className="flex gap-2">
                      {bounty.tags.map((tag: string) => (
                        <span key={tag} className="px-2 py-0.5 rounded-full bg-background/50 border border-border/50 text-xs">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 md:border-l md:border-border/50 md:pl-6">
                  <div className="text-right">
                    <div className="text-2xl font-mono font-bold text-accent">{bounty.amount}</div>
                    <div className="text-xs text-primary font-mono">{bounty.reward} XP</div>
                  </div>
                  <Button size="lg" className="bg-primary/10 text-primary hover:bg-primary/20 border border-primary/30">
                    Accept Mission
                  </Button>
                </div>
              </div>
            </Card>
          )) : (
            <Card className="p-6 border-border/50 bg-card/30 backdrop-blur-sm">
              <p className="text-muted-foreground">Loading bounties...</p>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
}
