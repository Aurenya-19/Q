import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Code, Palette, Gamepad2, Cpu, Globe } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function Communities() {
  const { data: communities = [] } = useQuery({
    queryKey: ["communities"],
    queryFn: async () => {
      const res = await fetch("/api/communities");
      return res.json();
    },
  });

  const getCategoryIcon = (category: string) => {
    const iconMap: Record<string, typeof Palette> = {
      Frontend: Palette,
      Backend: Code,
      "Game Dev": Gamepad2,
      "AI/ML": Cpu,
      Web3: Globe,
    };
    return iconMap[category] || Palette;
  };

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex justify-between items-end">
          <div>
            <h1 className="text-4xl font-display font-bold mb-2">Communities</h1>
            <p className="text-muted-foreground">Find your tribe and collaborate on projects.</p>
          </div>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Create Community</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.isArray(communities) && communities.length > 0 ? communities.map((c: any) => {
            const Icon = getCategoryIcon(c.category);
            return (
              <Card key={c.id} className="p-6 border-border/50 bg-card/30 backdrop-blur-sm hover:border-primary/50 transition-all duration-300 hover:-translate-y-1 group">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors text-2xl">
                  {c.icon}
                </div>
                <h3 className="text-xl font-display font-bold mb-2">{c.name}</h3>
                <p className="text-muted-foreground mb-6 text-sm">{c.description}</p>
                <div className="flex items-center justify-between pt-4 border-t border-border/50">
                  <div className="flex items-center gap-2 text-muted-foreground text-sm">
                    <Users className="w-4 h-4" />
                    <span>{c.memberCount.toLocaleString()} Members</span>
                  </div>
                  <Button variant="ghost" className="text-accent hover:text-accent hover:bg-accent/10 -mr-2">
                    Join
                  </Button>
                </div>
              </Card>
            );
          }) : (
            <Card className="p-6 border-border/50 bg-card/30 backdrop-blur-sm">
              <p className="text-muted-foreground">Loading communities...</p>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
}
