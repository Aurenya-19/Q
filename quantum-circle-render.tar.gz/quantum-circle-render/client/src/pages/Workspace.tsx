import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, MoreHorizontal, CheckCircle2, Circle, Clock } from "lucide-react";

export default function Workspace() {
  const columns = [
    {
      id: "todo",
      title: "To Do",
      color: "bg-red-500",
      tasks: [
        { id: 1, title: "Refactor Auth Middleware", tag: "Backend", priority: "High" },
        { id: 2, title: "Update Dependencies", tag: "Maint", priority: "Low" }
      ]
    },
    {
      id: "in-progress",
      title: "In Progress",
      color: "bg-yellow-500",
      tasks: [
        { id: 3, title: "Design System Integration", tag: "Frontend", priority: "High" },
        { id: 4, title: "API Endpoint Testing", tag: "QA", priority: "Medium" }
      ]
    },
    {
      id: "done",
      title: "Completed",
      color: "bg-green-500",
      tasks: [
        { id: 5, title: "Setup CI/CD Pipeline", tag: "DevOps", priority: "High" },
        { id: 6, title: "Initial Mockups", tag: "Design", priority: "Medium" }
      ]
    }
  ];

  return (
    <Layout>
      <div className="h-[calc(100vh-8rem)] flex flex-col">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-display font-bold text-glow">Workspace</h1>
            <p className="text-muted-foreground">Manage your projects and tasks.</p>
          </div>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" /> New Task
          </Button>
        </div>

        <div className="flex-1 overflow-x-auto pb-4">
          <div className="flex gap-6 h-full min-w-[800px]">
            {columns.map(col => (
              <div key={col.id} className="flex-1 flex flex-col gap-4 min-w-[300px]">
                <div className="flex items-center justify-between p-2">
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${col.color}`} />
                    <h3 className="font-bold font-ui tracking-wide uppercase text-sm">{col.title}</h3>
                    <Badge variant="secondary" className="ml-2 bg-muted text-muted-foreground">{col.tasks.length}</Badge>
                  </div>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </div>

                <div className="flex-1 bg-card/20 rounded-xl border border-border/30 p-3 space-y-3 overflow-y-auto">
                  {col.tasks.map(task => (
                    <Card key={task.id} className="p-4 border-border/50 bg-card/50 hover:border-primary/50 cursor-pointer transition-colors group">
                      <div className="flex justify-between items-start mb-3">
                        <Badge variant="outline" className="border-primary/20 text-primary/80 text-[10px]">
                          {task.tag}
                        </Badge>
                        <div className={`w-2 h-2 rounded-full ${
                          task.priority === 'High' ? 'bg-red-500' : 
                          task.priority === 'Medium' ? 'bg-yellow-500' : 'bg-blue-500'
                        }`} />
                      </div>
                      <h4 className="font-bold text-sm mb-4 group-hover:text-primary transition-colors">{task.title}</h4>
                      <div className="flex items-center justify-between text-muted-foreground text-xs">
                        <div className="flex -space-x-2">
                           <div className="w-6 h-6 rounded-full bg-muted border border-card flex items-center justify-center text-[8px]">NW</div>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" /> 2d
                        </div>
                      </div>
                    </Card>
                  ))}
                  <Button variant="ghost" className="w-full border border-dashed border-border/50 text-muted-foreground hover:text-primary hover:border-primary/50 hover:bg-primary/5">
                    <Plus className="w-4 h-4 mr-2" /> Add Item
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}
