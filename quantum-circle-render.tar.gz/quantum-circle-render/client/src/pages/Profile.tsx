import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Settings, Edit, MapPin, Link as LinkIcon, Calendar } from "lucide-react";

export default function Profile() {
  return (
    <Layout>
      <div className="space-y-8">
        {/* Profile Header */}
        <div className="relative">
          <div className="h-48 w-full rounded-xl bg-gradient-to-r from-primary/20 via-accent/20 to-primary/20 border border-white/5"></div>
          <div className="absolute -bottom-16 left-8 flex items-end gap-6">
            <div className="w-32 h-32 rounded-full border-4 border-background bg-card overflow-hidden">
              <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=NeonWalker" alt="Profile" className="w-full h-full bg-muted" />
            </div>
            <div className="mb-4 space-y-1">
              <h1 className="text-3xl font-display font-bold text-glow">NeonWalker</h1>
              <p className="text-muted-foreground">@neonwalker • Level 42</p>
            </div>
          </div>
          <div className="absolute bottom-4 right-8 flex gap-3">
             <Button variant="outline" size="sm" className="border-border/50 gap-2">
               <Settings className="w-4 h-4" /> Settings
             </Button>
             <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2">
               <Edit className="w-4 h-4" /> Edit Profile
             </Button>
          </div>
        </div>

        <div className="pt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Left Sidebar Info */}
          <div className="space-y-6">
            <Card className="p-6 border-border/50 bg-card/30 backdrop-blur-sm">
              <h3 className="font-bold font-ui mb-4">About</h3>
              <p className="text-sm text-muted-foreground mb-6">
                Full-stack developer obsessed with cyberpunk aesthetics and quantum computing. Building the future one line of code at a time.
              </p>
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-3 text-muted-foreground">
                  <MapPin className="w-4 h-4 text-primary" />
                  <span>Neo Tokyo, Digital Realm</span>
                </div>
                <div className="flex items-center gap-3 text-muted-foreground">
                  <LinkIcon className="w-4 h-4 text-primary" />
                  <a href="#" className="text-accent hover:underline">neonwalker.dev</a>
                </div>
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Calendar className="w-4 h-4 text-primary" />
                  <span>Joined March 2024</span>
                </div>
              </div>
            </Card>

            <Card className="p-6 border-border/50 bg-card/30 backdrop-blur-sm">
              <h3 className="font-bold font-ui mb-4">Skills</h3>
              <div className="flex flex-wrap gap-2">
                {["React", "Node.js", "GraphQL", "Web3", "CyberSecurity", "UI/UX"].map(skill => (
                  <Badge key={skill} variant="secondary" className="bg-secondary/20 text-secondary-foreground hover:bg-secondary/30">
                    {skill}
                  </Badge>
                ))}
              </div>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <div className="md:col-span-2">
            <Tabs defaultValue="posts" className="w-full">
              <TabsList className="w-full justify-start bg-card/30 border border-border/50 p-1 h-auto rounded-lg">
                <TabsTrigger value="posts" className="flex-1 data-[state=active]:bg-primary/20 data-[state=active]:text-primary">Posts</TabsTrigger>
                <TabsTrigger value="projects" className="flex-1 data-[state=active]:bg-primary/20 data-[state=active]:text-primary">Projects</TabsTrigger>
                <TabsTrigger value="media" className="flex-1 data-[state=active]:bg-primary/20 data-[state=active]:text-primary">Media</TabsTrigger>
                <TabsTrigger value="likes" className="flex-1 data-[state=active]:bg-primary/20 data-[state=active]:text-primary">Likes</TabsTrigger>
              </TabsList>
              
              <TabsContent value="posts" className="mt-6 space-y-4">
                {[1, 2].map((i) => (
                   <Card key={i} className="p-6 border-border/50 bg-card/30">
                     <div className="flex gap-4">
                       <div className="w-10 h-10 rounded-full bg-muted overflow-hidden">
                         <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=NeonWalker" alt="Avatar" />
                       </div>
                       <div>
                         <h4 className="font-bold">NeonWalker</h4>
                         <p className="text-xs text-muted-foreground">Just now</p>
                       </div>
                     </div>
                     <p className="mt-4 text-muted-foreground">
                       Exploring the new boundaries of interface design. What do you guys think about glassmorphism combined with brutalist typography? #design #ui
                     </p>
                   </Card>
                ))}
              </TabsContent>
              
              <TabsContent value="projects">
                <div className="text-center py-12 text-muted-foreground">
                  No projects showcased yet.
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </Layout>
  );
}
