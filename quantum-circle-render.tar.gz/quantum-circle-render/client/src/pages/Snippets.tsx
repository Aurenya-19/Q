import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Copy, Star, Share2, Code2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function Snippets() {
  const { data: snippets = [] } = useQuery({
    queryKey: ["snippets"],
    queryFn: async () => {
      const res = await fetch("/api/snippets");
      return res.json();
    },
  });

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex justify-between items-end">
          <div>
            <h1 className="text-4xl font-display font-bold mb-2 text-glow">Snippet Library</h1>
            <p className="text-muted-foreground">Reusable code blocks from the community.</p>
          </div>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Code2 className="w-4 h-4 mr-2" /> Share Snippet
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {Array.isArray(snippets) && snippets.length > 0 ? snippets.map((snippet: any) => (
            <Card key={snippet.id} className="border-border/50 bg-card/30 backdrop-blur-sm overflow-hidden group">
              <div className="p-4 border-b border-border/50 flex justify-between items-center bg-card/50">
                <div>
                  <h3 className="font-bold font-ui text-lg">{snippet.title}</h3>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>by User</span>
                    <span>•</span>
                    <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20 hover:bg-primary/20">
                      {snippet.language}
                    </Badge>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-yellow-400">
                    <Star className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary">
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="p-4 bg-black/40 font-mono text-sm overflow-x-auto">
                <pre className="text-gray-300">
                  {snippet.code}
                </pre>
              </div>
              <div className="p-3 bg-card/30 flex justify-between items-center text-xs text-muted-foreground">
                <span>{snippet.likes} stars</span>
                <span>Recently added</span>
              </div>
            </Card>
          )) : (
            <Card className="border-border/50 bg-card/30 backdrop-blur-sm p-6">
              <p className="text-muted-foreground">Loading snippets...</p>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
}
