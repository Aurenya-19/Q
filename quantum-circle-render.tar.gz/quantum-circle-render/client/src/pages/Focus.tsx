import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, RotateCcw, Music, Volume2, CheckCircle, Target } from "lucide-react";
import { useState, useEffect } from "react";

export default function Focus() {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [sessionType, setSessionType] = useState("Focus"); // Focus, Short Break, Long Break

  useEffect(() => {
    let interval: any = null;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((timeLeft) => timeLeft - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsActive(false);
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const toggleTimer = () => setIsActive(!isActive);
  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(25 * 60);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-display font-bold text-glow mb-2">Deep Focus Protocol</h1>
          <p className="text-muted-foreground">Sync your brainwaves. Eliminate distractions. Ship code.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Timer */}
          <Card className="lg:col-span-2 p-8 border-primary/20 bg-card/30 backdrop-blur-sm flex flex-col items-center justify-center relative overflow-hidden min-h-[400px]">
            <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent animate-pulse pointer-events-none" />
            
            <div className="flex gap-4 mb-8 z-10">
               {["Focus", "Short Break", "Long Break"].map(type => (
                 <Button 
                   key={type} 
                   variant={sessionType === type ? "default" : "outline"} 
                   onClick={() => { setSessionType(type); setTimeLeft(type === "Focus" ? 25*60 : type === "Short Break" ? 5*60 : 15*60); setIsActive(false); }}
                   className={`rounded-full ${sessionType === type ? "bg-primary text-primary-foreground" : "border-primary/30 text-primary/80"}`}
                 >
                   {type}
                 </Button>
               ))}
            </div>

            <div className="relative z-10 mb-8 group cursor-pointer" onClick={toggleTimer}>
              <div className="text-[8rem] font-mono font-bold tabular-nums leading-none tracking-tighter text-transparent bg-clip-text bg-gradient-to-b from-white to-white/50 group-hover:scale-105 transition-transform duration-300">
                {formatTime(timeLeft)}
              </div>
              <div className={`absolute -inset-4 rounded-full border-4 border-primary/20 ${isActive ? "animate-ping opacity-20" : "hidden"}`} />
            </div>

            <div className="flex gap-6 z-10">
              <Button size="lg" className="h-16 w-16 rounded-full bg-primary hover:bg-primary/90 shadow-[0_0_20px_rgba(0,255,255,0.3)]" onClick={toggleTimer}>
                {isActive ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8 ml-1" />}
              </Button>
              <Button size="lg" variant="outline" className="h-16 w-16 rounded-full border-border/50 hover:bg-white/5" onClick={resetTimer}>
                <RotateCcw className="w-6 h-6" />
              </Button>
            </div>
          </Card>

          {/* Sidebar Controls */}
          <div className="space-y-6">
            {/* Session Goals */}
            <Card className="p-6 border-border/50 bg-card/30">
              <div className="flex items-center gap-2 mb-4 text-primary">
                <Target className="w-5 h-5" />
                <h3 className="font-bold font-display">Session Goal</h3>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5 border border-white/5">
                  <div className="w-5 h-5 rounded border border-primary/50 flex items-center justify-center cursor-pointer hover:bg-primary/20">
                    <CheckCircle className="w-3 h-3 text-primary opacity-0 hover:opacity-50" />
                  </div>
                  <span className="text-sm">Refactor Authentication</span>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5 border border-white/5">
                   <div className="w-5 h-5 rounded border border-primary/50 flex items-center justify-center cursor-pointer hover:bg-primary/20"></div>
                   <input placeholder="Add a goal..." className="bg-transparent border-none text-sm focus:outline-none w-full" />
                </div>
              </div>
            </Card>

            {/* Ambient Sound */}
            <Card className="p-6 border-border/50 bg-card/30">
              <div className="flex items-center gap-2 mb-4 text-accent">
                <Music className="w-5 h-5" />
                <h3 className="font-bold font-display">Ambient Sound</h3>
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                   <span className="text-sm">Cyberpunk Rain</span>
                   <Button size="sm" variant="ghost" className="h-8 w-8 p-0"><Play className="w-3 h-3" /></Button>
                </div>
                <div className="flex items-center gap-2">
                   <Volume2 className="w-4 h-4 text-muted-foreground" />
                   <Slider defaultValue={[50]} max={100} step={1} className="flex-1" />
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
