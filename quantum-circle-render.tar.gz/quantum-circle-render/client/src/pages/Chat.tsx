import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, MoreVertical, Phone, Video } from "lucide-react";
import { useState } from "react";

export default function Chat() {
  const [messages, setMessages] = useState([
    { id: 1, text: "Hey, did you check out the new quantum algorithm?", sender: "them", time: "10:00 AM" },
    { id: 2, text: "Yeah, it's mind-blowing! The efficiency gains are insane.", sender: "me", time: "10:02 AM" },
    { id: 3, text: "I'm thinking of implementing it in our next project.", sender: "them", time: "10:05 AM" },
    { id: 4, text: "Let's do it. I'll set up the repo.", sender: "me", time: "10:06 AM" },
  ]);
  const [inputValue, setInputValue] = useState("");

  const handleSend = () => {
    if (!inputValue.trim()) return;
    setMessages([...messages, { id: Date.now(), text: inputValue, sender: "me", time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
    setInputValue("");
  };

  return (
    <Layout>
      <div className="h-[calc(100vh-8rem)] flex gap-6 rounded-2xl overflow-hidden border border-border/50 bg-card/30 backdrop-blur-sm">
        {/* Contacts List */}
        <div className="w-80 border-r border-border/50 hidden md:flex flex-col bg-card/20">
          <div className="p-4 border-b border-border/50">
            <h2 className="font-display font-bold text-lg text-primary">Messages</h2>
          </div>
          <ScrollArea className="flex-1">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className={`p-4 flex items-center gap-3 hover:bg-primary/5 cursor-pointer transition-colors ${i === 1 ? "bg-primary/10" : ""}`}>
                <div className="w-10 h-10 rounded-full bg-muted border border-primary/30 overflow-hidden">
                   <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${i*10}`} alt="Avatar" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-bold text-sm truncate">Neon_User_{i}</h3>
                    <span className="text-xs text-muted-foreground">10:0{i} AM</span>
                  </div>
                  <p className="text-xs text-muted-foreground truncate">Latest message preview goes here...</p>
                </div>
              </div>
            ))}
          </ScrollArea>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col min-w-0">
          <div className="p-4 border-b border-border/50 flex justify-between items-center bg-card/20">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-muted border border-primary/30 overflow-hidden">
                <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=10`} alt="Avatar" />
              </div>
              <div>
                <h3 className="font-bold font-ui">Neon_User_1</h3>
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-xs text-muted-foreground">Online</span>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" size="icon"><Phone className="w-4 h-4" /></Button>
              <Button variant="ghost" size="icon"><Video className="w-4 h-4" /></Button>
              <Button variant="ghost" size="icon"><MoreVertical className="w-4 h-4" /></Button>
            </div>
          </div>

          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.sender === "me" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                    msg.sender === "me" 
                      ? "bg-primary text-primary-foreground rounded-tr-none" 
                      : "bg-muted text-foreground rounded-tl-none"
                  }`}>
                    <p className="text-sm">{msg.text}</p>
                    <span className="text-[10px] opacity-70 block text-right mt-1">{msg.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="p-4 border-t border-border/50 bg-card/20">
            <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="flex gap-2">
              <Input 
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Type your message..." 
                className="bg-background/50 border-primary/20 focus-visible:ring-primary"
              />
              <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  );
}
