import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share2, Zap } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function Home() {
  const { data: posts = [] } = useQuery({
    queryKey: ["posts"],
    queryFn: async () => {
      const res = await fetch("/api/posts");
      return res.json();
    },
  });

  return (
    <Layout>
      <div className="space-y-8">
        {/* Hero Section */}
        <section className="relative overflow-hidden rounded-2xl border border-primary/20 bg-card/50 p-8 md:p-12">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-accent/10" />
          <div className="relative z-10 max-w-2xl">
            <Badge className="mb-4 bg-primary/20 text-primary hover:bg-primary/30 border-primary/50 font-ui">
              Welcome to the Nexus
            </Badge>
            <h1 className="text-4xl md:text-6xl font-display font-bold mb-6 leading-tight">
              Connect. Evolve. <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent text-glow">
                Transcend.
              </span>
            </h1>
            <p className="text-lg text-muted-foreground mb-8 font-ui max-w-lg">
              Join the Quantum Circle. Collaborate with visionaries, climb the leaderboard, and shape the future of the digital frontier.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="bg-primary text-background hover:bg-primary/90 font-ui font-bold">
                Start Creating
              </Button>
              <Button size="lg" variant="outline" className="border-primary/50 text-primary hover:bg-primary/10 font-ui">
                Explore Communities
              </Button>
            </div>
          </div>
        </section>

        {/* Feed Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <h2 className="text-2xl font-display font-bold flex items-center gap-2">
              <Zap className="w-6 h-6 text-accent" />
              Live Feed
            </h2>
            
            {Array.isArray(posts) && posts.length > 0 ? posts.map((post: any, i: number) => (
              <Card key={post.id} className="p-6 border-border/50 bg-card/30 backdrop-blur-sm hover:border-primary/30 transition-colors group">
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-full bg-muted flex-shrink-0 overflow-hidden border border-primary/30">
                    <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${post.userId}`} alt="Avatar" className="w-full h-full" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-bold font-ui text-lg group-hover:text-primary transition-colors">User_{i + 1}</h3>
                        <span className="text-xs text-muted-foreground">Just now</span>
                      </div>
                      <Badge variant="outline" className="border-accent/50 text-accent text-xs">
                        Update
                      </Badge>
                    </div>
                    <p className="text-muted-foreground mb-4 leading-relaxed">
                      {post.content}
                    </p>
                    <div className="flex items-center gap-6 text-sm text-muted-foreground">
                      <button className="flex items-center gap-2 hover:text-primary transition-colors">
                        <Heart className="w-4 h-4" />
                        <span>{post.likes}</span>
                      </button>
                      <button className="flex items-center gap-2 hover:text-primary transition-colors">
                        <MessageCircle className="w-4 h-4" />
                        <span>{post.commentsCount}</span>
                      </button>
                      <button className="flex items-center gap-2 hover:text-primary transition-colors">
                        <Share2 className="w-4 h-4" />
                        <span>Share</span>
                      </button>
                    </div>
                  </div>
                </div>
              </Card>
            )) : (
              <Card className="p-6 border-border/50 bg-card/30 backdrop-blur-sm">
                <p className="text-muted-foreground">Loading feed...</p>
              </Card>
            )}
          </div>

          {/* Sidebar Widgets */}
          <div className="space-y-6">
            <Card className="p-6 border-border/50 bg-card/30">
              <h3 className="font-display font-bold text-xl mb-4 text-primary">Trending</h3>
              <div className="space-y-4">
                {["#QuantumComputing", "#CyberSec", "#NeuralLinks", "#DesignSystems"].map((tag) => (
                  <div key={tag} className="flex items-center justify-between group cursor-pointer">
                    <span className="text-muted-foreground group-hover:text-foreground transition-colors">{tag}</span>
                    <span className="text-xs text-primary/70">2.4k posts</span>
                  </div>
                ))}
              </div>
            </Card>
            
            <Card className="p-6 border-border/50 bg-gradient-to-br from-accent/10 to-transparent">
              <h3 className="font-display font-bold text-xl mb-2">Pro Membership</h3>
              <p className="text-sm text-muted-foreground mb-4">Unlock advanced analytics and custom themes.</p>
              <Button className="w-full bg-accent text-white hover:bg-accent/90">Upgrade Now</Button>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
