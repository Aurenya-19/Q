import { Layout } from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Rocket, Star, Zap, Brain, Code, Layers, ArrowRight, Lock } from "lucide-react";

export default function Nexus() {
  const skills = [
    { name: "Quantum Logic", level: 65, color: "bg-primary" },
    { name: "Neural Arch", level: 42, color: "bg-accent" },
    { name: "Cyber Defense", level: 88, color: "bg-red-500" },
  ];

  const projects = [
    { 
      title: "Build a Decentralized Chat", 
      desc: "Learn P2P networking and encryption basics.", 
      xp: 500, 
      difficulty: "Beginner",
      icon: Lock
    },
    { 
      title: "Train an Image Classifier", 
      desc: "Introduction to Computer Vision with TensorFlow.js.", 
      xp: 1200, 
      difficulty: "Intermediate",
      icon: Brain
    },
    { 
      title: "Create a 3D Portfolio", 
      desc: "Master Three.js and WebGL shaders.", 
      xp: 800, 
      difficulty: "Intermediate",
      icon: Layers
    },
  ];

  return (
    <Layout>
      <div className="space-y-12">
        {/* Hero Section */}
        <div className="relative rounded-2xl overflow-hidden p-8 md:p-12 border border-primary/20 bg-gradient-to-br from-primary/10 via-background to-accent/10">
          <div className="relative z-10">
            <Badge className="mb-4 bg-primary/20 text-primary border-primary/50">Project Nexus</Badge>
            <h1 className="text-4xl md:text-6xl font-display font-bold mb-6 text-glow">
              Discover Your <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
                Next Breakthrough
              </span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-xl mb-8">
              The Nexus is your gateway to experimental projects, skill mastery, and the bleeding edge of technology. Don't just consume tech—forge it.
            </p>
            <div className="flex gap-4">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold shadow-[0_0_20px_rgba(0,255,255,0.3)]">
                <Rocket className="w-4 h-4 mr-2" /> Generate Mission
              </Button>
              <Button size="lg" variant="outline" className="border-primary/30 hover:bg-primary/10">
                View Skill Tree
              </Button>
            </div>
          </div>
          
          {/* Abstract Background Elements */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 blur-[100px] rounded-full mix-blend-screen pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-accent/20 blur-[80px] rounded-full mix-blend-screen pointer-events-none" />
        </div>

        {/* Active Quests / Projects */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <h2 className="text-2xl font-display font-bold flex items-center gap-2">
              <Zap className="w-6 h-6 text-yellow-400" /> Recommended Quests
            </h2>
            <div className="grid gap-4">
              {projects.map((project, i) => {
                const Icon = project.icon;
                return (
                  <Card key={i} className="group p-6 border-border/50 bg-card/30 backdrop-blur-sm hover:border-primary/50 transition-all hover:-translate-y-1 cursor-pointer relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    <div className="flex items-start justify-between relative z-10">
                      <div className="flex gap-4">
                        <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                          <Icon className="w-6 h-6 text-foreground" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold font-display mb-1 group-hover:text-primary transition-colors">{project.title}</h3>
                          <p className="text-muted-foreground text-sm mb-3">{project.desc}</p>
                          <div className="flex gap-2">
                            <Badge variant="secondary" className="bg-background/50 border-border text-xs">
                              +{project.xp} XP
                            </Badge>
                            <Badge variant="outline" className="border-border text-muted-foreground text-xs">
                              {project.difficulty}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all">
                        <ArrowRight className="w-5 h-5" />
                      </Button>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Skill Matrix Widget */}
          <div className="space-y-6">
            <Card className="p-6 border-border/50 bg-card/30 backdrop-blur-sm">
              <h2 className="text-xl font-display font-bold mb-6 flex items-center gap-2">
                <Code className="w-5 h-5 text-accent" /> Skill Matrix
              </h2>
              <div className="space-y-6">
                {skills.map((skill) => (
                  <div key={skill.name} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-bold">{skill.name}</span>
                      <span className="font-mono text-muted-foreground">{skill.level}%</span>
                    </div>
                    <Progress value={skill.level} className="h-2 bg-muted" />
                  </div>
                ))}
              </div>
              <Button className="w-full mt-6 border border-dashed border-border hover:border-primary hover:text-primary hover:bg-primary/5" variant="ghost">
                View Full Tree
              </Button>
            </Card>

            <Card className="p-6 border-yellow-500/30 bg-yellow-500/5 relative overflow-hidden">
              <div className="relative z-10">
                <h3 className="font-bold font-display text-yellow-500 mb-2 flex items-center gap-2">
                  <Star className="w-4 h-4 fill-yellow-500" /> Daily Challenge
                </h3>
                <p className="text-sm text-yellow-200/80 mb-4">
                  "Fix the memory leak in the holographic renderer."
                </p>
                <div className="flex justify-between items-center">
                  <Badge className="bg-yellow-500/20 text-yellow-500 border-yellow-500/50">Hard</Badge>
                  <span className="font-mono text-yellow-500 font-bold">+250 XP</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
